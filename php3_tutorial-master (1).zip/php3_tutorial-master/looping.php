<?php
//while loop

// $a=1;
// while($a<=10){
//  echo "<ul>"; 
//   echo "<li>".$a."</li>";
//   $a++;
//   echo "</ul>"; 
// }

//do while loop
// $a=1;
// do{
//  echo "<ul>"; 
//   echo "<li>".$a."</li>";
//   $a++;
//   echo "</ul>"; 
// }while($a<=10);

//for loop
for($a=1;$a<=10;$a++){
  echo $a;
}

?>