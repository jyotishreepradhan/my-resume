<?php

//function without parameter
// function myfun(){
//   echo "suprava";
// }
// myfun();

//function with parameter
// function myfun1($a,$b){
//  $sum=$a+$b;
//  echo "sum=$sum";
// }
// myfun1(10,20);

//function with return value
// function myfun2($a,$b){
// $sum=$a+$b;
// return $sum;
// }
// $total=myfun2(30,40);
// echo "total=$total";

//Global variable
// $a=20;
// function myfun3(){
//   //global $a;
// echo "value of a inside function=",$GLOBALS['a'];
// }
// myfun3();
// echo "value of a outside function=$a";

//local varibale

// function myfun3(){
//   $a=20;
// echo "value of a inside function=$a";
// }
// myfun3();
// echo "value of a outside function=$a";

//static variable
function myfun4(){
 static $a=20;
echo "value=$a";//20,22,24
$a=$a+2;//22,24
}
myfun4();
myfun4();
myfun4();
?>
