<?php
// echo "hello Good evening";
// echo "welcome";

// $a=10;
// $a="hello";//string
// $a=30;
// $b=40;
// echo $a;
// echo "value=$b <br>";
// echo "value=",$a ."<br>";

// $str="ram";//string
// $str1='sita';//string

// //echo 'value=$b';
// echo "hello";

//= == ===

$x=10;
$z=10.0;
$y=10;
echo $x===$y;



?>