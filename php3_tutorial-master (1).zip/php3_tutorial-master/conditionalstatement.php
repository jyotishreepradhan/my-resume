<?php
// $a=20;
// $b=40;
// if($a>$b){
//   echo "greater";
// }
// else{
//   echo "smaller";
// }

// //
// $mark=20;
// if($mark>=60 && $mark<=100)
// echo "1st division";
// else if($mark>=40 && $mark<60)
// echo "2nd division";
// else if($mark>=30 && $mark<40)
// echo "3rd division";
// else
// echo "fail";

//switch statement
$a=20;
$b=30;
switch(false){
  case ($a>$b) : echo "greater";
                 break; 
  case ($a<$b) : echo "smaller";
  break;
  case ($a==$b) : echo "equal";
  break;
default: echo "try again";

}






?>