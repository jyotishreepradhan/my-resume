<?php
include "dbconfig.php";

if(isset($_POST["login"])){
  $email=$_POST['email'];
  $password=$_POST['password'];

  $sql="select * from empdata where email='$email' and password='$password'";
  $result=$con->query($sql);
  if($result->num_rows>0){
    $data=$result->fetch_assoc();
    session_start(); //1st step
    $_SESSION['email']=$data['email'];
    $_SESSION['password']=$data['password'];
    $_SESSION['empname']=$data['empname'];
    header("location:home.php");
  }
}


?>







<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <form action="" method="post">
  <input type="text" name="email" id="" placeholder="enter email" required>
  <input type="password" name="password" id="" placeholder="enter password" required>
  <input type="submit" value="login" name="login">
  </form>
</body>
</html>