<?php
include "dbconfig.php";

if(isset($_POST['register'])){
  $empname=$_POST['empname'];
  $email=$_POST['email'];
  $phone=$_POST['phone'];
  $designation=$_POST['designation'];
  $salary=$_POST['salary'];
  $password=$_POST['password'];

$sql="insert into empdata values(0,'$empname','$email','$phone','$designation',$salary,'$password')";
if($con->query($sql)){
  echo "data inserted successfully";
  //header("location:registration.php");
}
else{
  echo "try again";
}
}


?>