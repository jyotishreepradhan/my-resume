<?php
include "dbconfig.php";
session_start();
if(isset($_SESSION['email'])){

echo "welcome $_SESSION[empname]";
$sql="select * from empdata";
$result=$con->query($sql);
if($result->num_rows>0){

  echo "<table border=1>";
   echo "<tr><th>name</th>
        <th>email</th>
        <th>phone</th>
        <th>Designation</th>
        <th>Salary</th>
        </tr>";

  while($data=$result->fetch_assoc()){
    // echo "$data[empname] , $data[email]  <br>";

    echo "<tr>
              <td>$data[empname]</td>
              <td>$data[email]</td>
              <td>$data[phone]</td>
              <td>$data[designation]</td>
              <td>$data[salary]</td>

    </tr>";
  }
}
else{
  echo "no data found";
}
}

?>
</table>