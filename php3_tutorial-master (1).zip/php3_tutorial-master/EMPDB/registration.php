<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<a href="login.php">Login</a>
  <form action="registration_detail.php" method="post">
  <input type="text" name="empname" placeholder="name">
  <input type="email" name="email" placeholder="email">
  <input type="text" name="phone" placeholder="phone no.">
  <input type="text" name="designation" placeholder="designation">
  <input type="text" name="salary" placeholder="salary">
  <input type="password" name="password" placeholder="password">
<input type="submit" value="register" name="register">
  </form>
</body>
</html>