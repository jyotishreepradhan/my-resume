<?php

$con=new mysqli("localhost","root","","employeeinfo");
if($con->connect_error){
  die("something wrong in connection");
}

?>