<?php
//index array
// $arr=array(10,20,30,40);
// echo $arr[1];//20

// $arr1=[20,"30.ricky",5,true];
// // echo $arr1[2];

// for($i=0;$i<4;$i++){
//   echo $arr1[$i]."<br>";
// }

// foreach($arr1 as $v){
//   echo $v ."<br>";
// }

//Associative array
$arr=[1=>"Rima",2=>"Sima",3=>"Rahul",4=>"Ram"]; //Key=>value pair
//  echo $arr[4];
 foreach($arr as $v){
   echo "$v <br>";
 }

?>