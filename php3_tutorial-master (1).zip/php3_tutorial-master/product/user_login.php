<?php

include "dbconfig.php";

if(isset($_POST['login'])){
  $email=$_POST['email'];
  $password=$_POST['password'];

  $sql="select * from users where email='$email' and password='$password'";
  $result=$con->query($sql);
  if($result->num_rows>0){
    $data=$result->fetch_assoc();
    session_start();
    $_SESSION['email']=$data['email'];
    $_SESSION['id']=$data['id'];
    header("location:user_home.php");
  }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<h1>User Login Here</h1>
  <form action="" method="post">
  <input type="text" name="email" placeholder="email">
  <input type="password" name="password" placeholder="password">
  <input type="submit" value="login" name="login">
  </form>
</body>
</html>