<?php
$con=new mysqli("localhost","root","","product");
if($con->connect_error){
  die("something wrong in connection");
}
?>