<?php
include "dbconfig.php";
include "admin_home.php";
$id=$_GET['id'];
if(isset($_POST['update'])){
  $name=$_POST['name'];
  $model_number=$_POST['model_number'];
  $memory=$_POST['memory'];
  $color=$_POST['color'];
  $price=$_POST['price'];
  $category=$_POST['category'];
  $sql="update items set name='$name',model_number='$model_number',memory='$memory',color='$color',price='$price',category='$category' where id=$id";
  if($con->query($sql)){
    header("location:view_product.php");
  }
  else{
    header("location:update.php");
  }
}

$qry="select * from items where id=$id";
$result=$con->query($qry);
if($result->num_rows>0){
  $data=$result->fetch_assoc();
  $name=$data['name'];
  $model_number=$data['model_number'];
  $memory=$data['memory'];
  $color=$data['color'];
  $price=$data['price'];
  $category=$data['category'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>

<h1>update form</h1>
  <form action="" method="post">
  <input type="text" name="name" value="<?php echo $name;?>" placeholder="enter name">
  <input type="text" name="model_number" value="<?php echo $model_number;?>" placeholder="enter model number">
  <input type="text" name="memory" value="<?php echo $memory;?>" placeholder="enter memory">
  <input type="text" name="color" value="<?php echo $color;?>" placeholder="enter color">
  <input type="text" name="price" value="<?php echo $price;?>" placeholder="enter price">
  <input type="text" name="category" value="<?php echo $category;?>" placeholder="enter category">
  <input type="submit" value="update" name="update">
  </form>
</body>
</html>