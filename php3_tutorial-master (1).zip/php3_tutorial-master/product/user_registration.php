<?php
include "dbconfig.php";
$msg="";
if(isset($_POST['submit'])){
  $username=$_POST['username'];
  $email=$_POST['email'];
  $phone=$_POST['phone'];
  $address=$_POST['address'];
  $password=$_POST['password'];
  $cpassword=$_POST['cpassword'];

  $sql="insert into users values(0,'$username','$email','$phone','$address','$password')";
if($con->query($sql)){
  $msg="data inserted";
}
else{
  $msg="something wrong";
}

}



?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <center>
<h1>User Registration</h1>
<?php echo $msg;?>
<div>
  <form action="" method="post">
  <input type="text" name="username" id="" placeholder="username"><br/>
  <input type="text" name="email" id="" placeholder="email"><br/>
  <input type="text" name="phone" id="" placeholder="contact"><br/>
  <textarea name="address" id="" rows="5" cols="20" placeholder="address"></textarea><br/>
  <input type="password" name="password" id="" placeholder="password"><br/>
  <input type="password" name="cpassword" id="" placeholder="Confirm password"><br/>
  <input type="submit" value="submit" name="submit">

  </form>
</div>
</center>
</body>
</html>