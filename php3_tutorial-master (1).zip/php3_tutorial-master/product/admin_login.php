<?php

include "dbconfig.php";

if(isset($_POST['login'])){
  $username=$_POST['username'];
  $password=$_POST['password'];

  $sql="select * from admin where username='$username' and password='$password'";
  $result=$con->query($sql);
  if($result->num_rows>0){
    $data=$result->fetch_assoc();
    session_start();
    $_SESSION['username']=$data['username'];
    header("location:admin_home.php");
  }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<h1>Admin Login Here</h1>
  <form action="" method="post">
  <input type="text" name="username" placeholder="username">
  <input type="password" name="password" placeholder="password">
  <input type="submit" value="login" name="login">
  </form>
</body>
</html>