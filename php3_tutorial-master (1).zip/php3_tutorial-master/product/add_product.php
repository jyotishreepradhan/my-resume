<?php
include "admin_home.php";
include "dbconfig.php";

if(isset($_POST['submit'])){
  $name=$_POST['name'];
  $model_number=$_POST['model_number'];
  $memory=$_POST['memory'];
  $color=$_POST['color'];
  $price=$_POST['price'];
  $category=$_POST['category'];
  
  $sql="insert into items values(0,'$name','$model_number','$memory','$color','$price','$category')";
  if($con->query($sql)){
    ?>
    <script>
    alert("data inserted successfully");
    </script>
  <?php
  }
  else{
   ?>
    <script>
    alert("something wrong");
    </script>
   <?php
  }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>add product</title>
</head>
<body>
<h1>Add product here</h1>
  <form action="" method="post">
  <input type="text" name="name" id="" placeholder="product name">
  <input type="text" name="model_number" id="" placeholder="model number">
  <input type="text" name="memory" id="" placeholder="memory">
  <input type="text" name="color" id="" placeholder="color">
  <input type="text" name="price" id="" placeholder="price">
  <select name="category" id="">
    <option value="mobile">Mobiles</option>
    <option value="electronic">Electronic Accessories</option>
  </select>

  <input type="submit" value="Add product" name="submit">

  </form>
</body>
</html>