<?php
include "dbconfig.php";

$sql="select * from items where category='mobile'";
$result=$con->query($sql);
if($result->num_rows>0){
  $data=$result->fetch_assoc();
    $name=$data['name'];
    $model_number=$data['model_number'];
    $memory=$data['memory'];
    $color=$data['color'];
    $price=$data['price'];
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <div >
  <img src="images/moto.jpg" alt="" style="width:350px;height:400px"><br/>
  <span><?php echo $name;?></span><br/>
  <span><?php echo $model_number;?></span><br/>
  <span><?php echo $memory." GB";?></span><br/>
  <span><?php echo $color;?></span><br/>
  <span><?php echo $price;?></span><br/>

<a href="#">Add to cart</a>
</div>
</body>
</html>