<?php

$username=$_GET['username'];
$password=$_GET['password'];

echo "username=$username and password=$password";
?>