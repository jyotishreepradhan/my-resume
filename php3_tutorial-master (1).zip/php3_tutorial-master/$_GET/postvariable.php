<?php
 if(isset($_POST['submit'])){
  $username=$_REQUEST['username'];
  $password=$_REQUEST['password'];
  
  if($username=="suprava padhi" && $password=="asd"){

    header("location:aboutus.php?msg=success");
  }
  else{
    echo "something wrong.try again";
  }
}



?>