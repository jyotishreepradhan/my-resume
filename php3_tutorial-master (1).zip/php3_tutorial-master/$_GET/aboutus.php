<?php
$msg=$_GET['msg'];

if($msg=="success"){
  echo "welcome to about us page";
}

?>